import { Redirect } from "expo-router";

export default function MobileLayout() {
  return <Redirect href="https://web.example.com" />;
}
