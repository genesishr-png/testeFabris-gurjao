export default function Home() {
  return (
    <>
      <style global>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        html, body {
          width: 100%;
          height: 100%;
        }
        .hidden { display: none !important; }
        .tab-content.hidden { display: none !important; }
      `}</style>
      <div
        id="root"
        dangerouslySetInnerHTML={{
          __html: `<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sistema de Gestão Financeira - Advocacia</title>
	<script src="https://cdn.tailwindcss.com"></script>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style>
		body { font-family: 'Inter', sans-serif; position: relative; background-color: #0f172a; color: #d1d5db; }
		body::after { content: ''; position: fixed; z-index: -1; top: 0; left: 0; right: 0; bottom: 0; background-image: url('https://i.postimg.cc/x81V8QJg/Imagem-do-Whats-App-de-2025-10-27-a-s-09-49-28-f966cd35.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center; opacity: 0.12; }
		.modal-backdrop { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); z-index: 9000; }
		.modal { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9001; max-height: 90vh; overflow-y: auto; }
		.kanban-column { min-width: 320px; }
		.kanban-content { max-height: 60vh; overflow-y: auto; padding-right: 8px; }
		::-webkit-scrollbar { width: 8px; } ::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 10px; }
		.service-tag-small { display: inline-block; background-color: #374151; color: #9ca3af; padding: 2px 8px; border-radius: 9999px; font-size: 12px; margin-right: 4px; margin-bottom: 4px; }
		.nav-tab { cursor: pointer; padding: 10px 20px; border-bottom: 3px solid transparent; color: #9ca3af; transition: all 0.2s; }
		.nav-tab:hover { color: #e5e7eb; }
		.nav-tab.active { border-bottom-color: #6366f1; color: #e5e7eb; }
		.dark-card { background-color: #1f2937; border: 1px solid #374151; }
		.filter-select { background-color: #374151; border: 1px solid #4b5563; color: #9ca3af; padding: 8px 12px; border-radius: 6px; font-size: 14px; }
		#loading-overlay, #auth-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(17, 24, 39, 0.9); display: flex; justify-content: center; align-items: center; z-index: 10000; color: white; font-size: 1.2rem; }
		#app-container { display: none; }
		.admin-only { display: none; }
		body.is-admin .admin-only { display: block; }
		.login-modal { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); animation: fadeIn 0.3s ease; }
		.login-modal input { background-color: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); color: #ffffff; }
		@keyframes fadeIn { from { opacity: 0; transform: translate(-50%, -60%); } to { opacity: 1; transform: translate(-50%, -50%); } }
		.notification { position: fixed; top: 20px; right: 20px; background: #10b981; color: white; padding: 12px 16px; border-radius: 8px; z-index: 11000; animation: slideIn 0.3s ease; }
		@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
		.pagination-button { background-color: #374151; border: 1px solid #4b5563; color: #9ca3af; padding: 6px 12px; border-radius: 6px; font-size: 14px; cursor: pointer; transition: all 0.2s; }
		.pagination-button:hover:not(:disabled) { background-color: #4b5563; color: white; }
		.pagination-button.active { background-color: #4f46e5; border-color: #4f46e5; color: white; }
	</style>
</head>
<body class="text-gray-300">
	<div id="loading-overlay"><i class="fas fa-spinner fa-spin mr-3"></i> Conectando...</div>

	<div id="auth-overlay">
		<div class="w-full max-w-sm p-8 space-y-6 bg-transparent rounded-lg shadow-xl border border-indigo-800 login-modal">
			<img src="https://www.fabrisegurjao.adv.br/netpage/data/uploads/2019/12/logo-fabris-e-gurjao-491x325px.png" alt="Logo" class="w-48 mx-auto">
			<h2 class="text-2xl font-bold text-center">Bem-vindo ao Sistema</h2>
			<div id="auth-error" class="hidden p-3 text-sm text-red-300 bg-red-800/50 border border-red-700 rounded-lg"></div>
			<form id="login-form" class="space-y-4">
				<div>
					<label for="login-email" class="block text-sm font-medium text-gray-200">Email</label>
					<input type="email" id="login-email" required class="mt-1 block w-full px-3 py-2 bg-transparent border border-gray-400 rounded-md text-white">
				</div>
				<div>
					<label for="login-password" class="block text-sm font-medium text-gray-200">Senha</label>
					<input type="password" id="login-password" required class="mt-1 block w-full px-3 py-2 bg-transparent border border-gray-400 rounded-md text-white">
				</div>
				<button type="submit" class="w-full py-2 px-4 rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 mt-8">Entrar</button>
			</form>
		</div>
	</div>

	<div id="app-container" class="container mx-auto p-4 md:p-8">
		<div class="header-with-logo mb-8 pt-4">
			<div>
				<h1 class="text-3xl font-bold text-white mb-2">Gestão de Contratos</h1>
				<p class="text-gray-400">Bem-vindo(a), <span id="user-name" class="font-semibold text-indigo-400">...</span></p>
			</div>
		</div>

		<div class="flex border-b border-gray-700 mb-6 overflow-x-auto">
			<button class="nav-tab active" data-tab="dashboard"><i class="fas fa-th-large mr-2"></i>Dashboard</button>
			<button class="nav-tab" data-tab="kanban"><i class="fas fa-columns mr-2"></i>Kanban</button>
			<button class="nav-tab" data-tab="contracts"><i class="fas fa-file-contract mr-2"></i>Contratos</button>
			<button class="nav-tab" data-tab="reports"><i class="fas fa-chart-bar mr-2"></i>Relatórios</button>
			<button class="nav-tab admin-only" data-tab="settings"><i class="fas fa-cog mr-2"></i>Config</button>
			<div style="flex: 1;"></div>
			<button id="logout-button" class="nav-tab text-red-400"><i class="fas fa-sign-out-alt mr-2"></i>Sair</button>
		</div>

		<div id="dashboard-content" class="tab-content active">
			<div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
				<div class="dark-card p-6 rounded-lg"><div class="flex justify-between items-start"><div><p class="text-gray-400 text-sm">Total</p><p class="text-3xl font-bold text-white" id="total-contracts">0</p></div><i class="fas fa-file-contract text-indigo-500 text-3xl opacity-20"></i></div></div>
				<div class="dark-card p-6 rounded-lg"><div class="flex justify-between items-start"><div><p class="text-gray-400 text-sm">Aberto</p><p class="text-3xl font-bold text-yellow-400" id="open-contracts">0</p></div><i class="fas fa-clock text-yellow-500 text-3xl opacity-20"></i></div></div>
				<div class="dark-card p-6 rounded-lg"><div class="flex justify-between items-start"><div><p class="text-gray-400 text-sm">Progresso</p><p class="text-3xl font-bold text-blue-400" id="progress-contracts">0</p></div><i class="fas fa-spinner text-blue-500 text-3xl opacity-20"></i></div></div>
				<div class="dark-card p-6 rounded-lg"><div class="flex justify-between items-start"><div><p class="text-gray-400 text-sm">Fechado</p><p class="text-3xl font-bold text-green-400" id="closed-contracts">0</p></div><i class="fas fa-check-circle text-green-500 text-3xl opacity-20"></i></div></div>
			</div>
			<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
				<div class="dark-card p-6 rounded-lg"><h3 class="text-lg font-semibold text-white mb-4">Por Status</h3><canvas id="statusChart"></canvas></div>
				<div class="dark-card p-6 rounded-lg"><h3 class="text-lg font-semibold text-white mb-4">Por Serviço</h3><canvas id="servicesChart"></canvas></div>
			</div>
		</div>

		<div id="kanban-content" class="tab-content hidden">
			<div class="flex gap-4 overflow-x-auto pb-4">
				<div class="kanban-column dark-card rounded-lg p-4">
					<h3 class="text-lg font-semibold text-white mb-4"><span class="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>Aberto</h3>
					<div class="kanban-content" id="kanban-open"></div>
				</div>
				<div class="kanban-column dark-card rounded-lg p-4">
					<h3 class="text-lg font-semibold text-white mb-4"><span class="inline-block w-3 h-3 bg-blue-500 rounded-full mr-2"></span>Progresso</h3>
					<div class="kanban-content" id="kanban-progress"></div>
				</div>
				<div class="kanban-column dark-card rounded-lg p-4">
					<h3 class="text-lg font-semibold text-white mb-4"><span class="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>Fechado</h3>
					<div class="kanban-content" id="kanban-closed"></div>
				</div>
			</div>
		</div>

		<div id="contracts-content" class="tab-content hidden">
			<div class="flex justify-between items-center mb-6">
				<h2 class="text-2xl font-bold text-white">Contratos</h2>
				<button id="add-contract-btn" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg"><i class="fas fa-plus mr-2"></i>Novo</button>
			</div>
			<div class="dark-card p-6 rounded-lg mb-6">
				<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
					<input type="text" id="filter-client" placeholder="Cliente..." class="filter-select">
					<select id="filter-status" class="filter-select"><option value="">Todos</option><option value="Aberto">Aberto</option><option value="Em Progresso">Progresso</option><option value="Fechado">Fechado</option></select>
					<select id="filter-service" class="filter-select"><option value="">Todos</option><option value="Assessoria">Assessoria</option><option value="Consultoria">Consultoria</option><option value="Litígio">Litígio</option></select>
				</div>
			</div>
			<div class="dark-card rounded-lg overflow-hidden">
				<table class="w-full text-sm"><thead class="bg-gray-800"><tr><th class="px-6 py-3 text-left">Cliente</th><th class="px-6 py-3 text-left">Serviços</th><th class="px-6 py-3 text-left">Status</th><th class="px-6 py-3 text-left">Valor</th><th class="px-6 py-3 text-right">Ações</th></tr></thead><tbody id="contracts-table-body"><tr><td colspan="5" class="px-6 py-4 text-center">Carregando...</td></tr></tbody></table>
				<div id="paginationContainer" class="p-4 border-t border-gray-700 flex justify-center gap-2"></div>
			</div>
		</div>

		<div id="reports-content" class="tab-content hidden">
			<h2 class="text-2xl font-bold text-white mb-6">Relatórios</h2>
			<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
				<div class="dark-card p-6 rounded-lg"><h3 class="text-lg font-semibold text-white mb-4">Evolução</h3><canvas id="evolutionChart"></canvas></div>
				<div class="dark-card p-6 rounded-lg"><h3 class="text-lg font-semibold text-white mb-4">Responsáveis</h3><canvas id="assigneeChart"></canvas></div>
			</div>
		</div>

		<div id="settings-content" class="tab-content hidden admin-only">
			<h2 class="text-2xl font-bold text-white mb-6">Configurações</h2>
			<div class="dark-card p-6 rounded-lg"><p class="text-gray-400">Configurações do sistema...</p></div>
		</div>
	</div>

	<div id="contract-modal" class="modal dark-card rounded-lg shadow-xl w-11/12 md:w-1/2">
		<div class="p-6">
			<div class="flex justify-between items-center mb-4">
				<h2 class="text-2xl font-bold text-white" id="modal-title">Novo Contrato</h2>
				<button onclick="closeModal()" class="text-gray-400 hover:text-white text-2xl">&times;</button>
			</div>
			<form id="contract-form" class="space-y-4">
				<div><label class="block text-sm font-medium text-gray-300 mb-1">Cliente</label><input type="text" id="form-client" class="filter-select w-full" required></div>
				<div><label class="block text-sm font-medium text-gray-300 mb-1">Descrição</label><textarea id="form-description" class="filter-select w-full h-20"></textarea></div>
				<div class="grid grid-cols-2 gap-4">
					<div><label class="block text-sm font-medium text-gray-300 mb-1">Status</label><select id="form-status" class="filter-select w-full"><option>Aberto</option><option>Em Progresso</option><option>Fechado</option></select></div>
					<div><label class="block text-sm font-medium text-gray-300 mb-1">Valor</label><input type="number" id="form-value" class="filter-select w-full" step="0.01" required></div>
				</div>
				<div><label class="block text-sm font-medium text-gray-300 mb-1">Serviços</label><input type="text" id="form-services" class="filter-select w-full" placeholder="Assessoria, Consultoria"></div>
				<div><label class="block text-sm font-medium text-gray-300 mb-1">Responsável</label><input type="text" id="form-assignee" class="filter-select w-full"></div>
				<div class="flex gap-3 pt-4">
					<button type="submit" class="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg">Salvar</button>
					<button type="button" onclick="closeModal()" class="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg">Cancelar</button>
				</div>
			</form>
		</div>
	</div>

	<div id="modal-backdrop" class="modal-backdrop" onclick="closeModal()"></div>

	<script type="module">
		import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
		import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
		import { getFirestore, collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

		let db, auth, contractsCollection;
		let contracts = [];
		let currentEditingId = null;
		let currentPage = 1;
		const CONTRACTS_PER_PAGE = 12;
		let filteredContracts = [];
		let statusChart = null, servicesChart = null;
		const ADMIN_USERS = ["Dra. Renata Fabris", "Dr. Felipe Gurjão", "Lilian"];

		window.closeModal = () => {
			document.getElementById('contract-modal').style.display = 'none';
			document.getElementById('modal-backdrop').style.display = 'none';
			currentEditingId = null;
		};

		window.openModal = () => {
			currentEditingId = null;
			document.getElementById('modal-title').textContent = 'Novo Contrato';
			document.getElementById('contract-form').reset();
			document.getElementById('contract-modal').style.display = 'block';
			document.getElementById('modal-backdrop').style.display = 'block';
		};

		window.editContract = (id) => {
			const contract = contracts.find(c => c.id === id);
			if (!contract) return;
			currentEditingId = id;
			document.getElementById('modal-title').textContent = 'Editar Contrato';
			document.getElementById('form-client').value = contract.client || '';
			document.getElementById('form-description').value = contract.description || '';
			document.getElementById('form-status').value = contract.status || 'Aberto';
			document.getElementById('form-value').value = contract.value || '';
			document.getElementById('form-services').value = contract.services || '';
			document.getElementById('form-assignee').value = contract.assignee || '';
			window.openModal();
		};

		window.deleteContract = (id) => {
			if (confirm('Deletar este contrato?')) {
				deleteDoc(doc(db, 'contracts', id)).catch(err => console.error('Erro:', err));
			}
		};

		window.goToPage = (page) => {
			currentPage = page;
			renderTable();
		};

		function updateStats() {
			const total = contracts.length;
			const open = contracts.filter(c => c.status === 'Aberto').length;
			const progress = contracts.filter(c => c.status === 'Em Progresso').length;
			const closed = contracts.filter(c => c.status === 'Fechado').length;
			document.getElementById('total-contracts').textContent = total;
			document.getElementById('open-contracts').textContent = open;
			document.getElementById('progress-contracts').textContent = progress;
			document.getElementById('closed-contracts').textContent = closed;
			updateCharts();
			renderKanban();
			applyFilters();
		}

		function updateCharts() {
			const statusData = { 'Aberto': 0, 'Em Progresso': 0, 'Fechado': 0 };
			const serviceData = {};
			contracts.forEach(c => {
				statusData[c.status || 'Aberto']++;
				if (c.services) {
					c.services.split(',').map(s => s.trim()).forEach(s => serviceData[s] = (serviceData[s] || 0) + 1);
				}
			});

			const statusCtx = document.getElementById('statusChart');
			if (statusCtx && statusCtx.parentElement) {
				if (statusChart) statusChart.destroy();
				statusChart = new Chart(statusCtx, {
					type: 'doughnut',
					data: { labels: Object.keys(statusData), datasets: [{ data: Object.values(statusData), backgroundColor: ['#FBBF24', '#3B82F6', '#10B981'], borderColor: '#1F2937', borderWidth: 2 }] },
					options: { responsive: true, plugins: { legend: { labels: { color: '#E5E7EB' } } } }
				});
			}

			const svcCtx = document.getElementById('servicesChart');
			if (svcCtx && svcCtx.parentElement) {
				if (servicesChart) servicesChart.destroy();
				servicesChart = new Chart(svcCtx, {
					type: 'bar',
					data: { labels: Object.keys(serviceData), datasets: [{ label: 'Contratos', data: Object.values(serviceData), backgroundColor: '#6366F1' }] },
					options: { responsive: true, scales: { y: { ticks: { color: '#9CA3AF' }, grid: { color: '#374151' } }, x: { ticks: { color: '#9CA3AF' }, grid: { color: '#374151' } } }, plugins: { legend: { labels: { color: '#E5E7EB' } } } }
				});
			}
		}

		function renderKanban() {
			['Aberto', 'Em Progresso', 'Fechado'].forEach((status, idx) => {
				const ids = ['kanban-open', 'kanban-progress', 'kanban-closed'];
				const el = document.getElementById(ids[idx]);
				if (!el) return;
				el.innerHTML = contracts.filter(c => c.status === status).map(c => \`
					<div class="dark-card p-4 rounded-lg mb-3 cursor-pointer hover:bg-gray-700" onclick="editContract('\${c.id}')">
						<h4 class="text-white font-semibold">\${c.client}</h4>
						<p class="text-gray-400 text-xs mt-1">\${c.description || 'Sem descr.'}</p>
						\${c.services ? '<div class="mt-2">' + c.services.split(',').map(s => '<span class="service-tag-small">' + s.trim() + '</span>').join('') + '</div>' : ''}
						<p class="text-indigo-400 font-bold mt-2">R$ \${(c.value || 0).toFixed(2)}</p>
					</div>
				\`).join('');
			});
		}

		function applyFilters() {
			const client = document.getElementById('filter-client')?.value.toLowerCase() || '';
			const status = document.getElementById('filter-status')?.value || '';
			const service = document.getElementById('filter-service')?.value || '';
			filteredContracts = contracts.filter(c => {
				return (!client || c.client.toLowerCase().includes(client)) &&
					(!status || c.status === status) &&
					(!service || (c.services && c.services.includes(service)));
			});
			currentPage = 1;
			renderTable();
		}

		function renderTable() {
			const start = (currentPage - 1) * CONTRACTS_PER_PAGE;
			const page = filteredContracts.slice(start, start + CONTRACTS_PER_PAGE);
			const tbody = document.getElementById('contracts-table-body');
			tbody.innerHTML = page.length ? page.map(c => \`
				<tr class="border-b border-gray-700 hover:bg-gray-800">
					<td class="px-6 py-4">\${c.client}</td>
					<td class="px-6 py-4 text-gray-300"><small>\${c.services || '-'}</small></td>
					<td class="px-6 py-4"><span class="px-3 py-1 rounded-full text-xs font-semibold \${c.status === 'Aberto' ? 'bg-yellow-900 text-yellow-200' : c.status === 'Em Progresso' ? 'bg-blue-900 text-blue-200' : 'bg-green-900 text-green-200'}">\${c.status}</span></td>
					<td class="px-6 py-4 text-indigo-400 font-bold">R$ \${(c.value || 0).toFixed(2)}</td>
					<td class="px-6 py-4 text-right">
						<button onclick="editContract('\${c.id}')" class="text-blue-400 mr-3"><i class="fas fa-edit"></i></button>
						<button onclick="deleteContract('\${c.id}')" class="text-red-400"><i class="fas fa-trash"></i></button>
					</td>
				</tr>
			\`).join('') : '<tr><td colspan="5" class="px-6 py-4 text-center">Nenhum contrato</td></tr>';

			const totalPages = Math.ceil(filteredContracts.length / CONTRACTS_PER_PAGE);
			const pag = document.getElementById('paginationContainer');
			pag.innerHTML = Array.from({length: totalPages}, (_, i) => i + 1).map(p => \`
				<button class="pagination-button \${p === currentPage ? 'active' : ''}" onclick="goToPage(\${p})">\${p}</button>
			\`).join('');
		}

		document.getElementById('contract-form')?.addEventListener('submit', async (e) => {
			e.preventDefault();
			const data = {
				client: document.getElementById('form-client').value,
				description: document.getElementById('form-description').value,
				status: document.getElementById('form-status').value,
				value: parseFloat(document.getElementById('form-value').value),
				services: document.getElementById('form-services').value,
				assignee: document.getElementById('form-assignee').value,
				createdAt: new Date().toISOString()
			};
			try {
				if (currentEditingId) {
					await updateDoc(doc(db, 'contracts', currentEditingId), data);
				} else {
					await addDoc(contractsCollection, data);
				}
				window.closeModal();
			} catch (err) {
				console.error('Erro:', err);
				alert('Erro ao salvar contrato');
			}
		});

		document.querySelectorAll('.nav-tab:not(#logout-button)').forEach(tab => {
			tab.addEventListener('click', (e) => {
				document.querySelectorAll('.nav-tab:not(#logout-button)').forEach(t => t.classList.remove('active'));
				document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
				e.target.closest('.nav-tab').classList.add('active');
				const tabName = e.target.closest('.nav-tab').getAttribute('data-tab');
				const content = document.getElementById(tabName + '-content');
				if (content) content.classList.remove('hidden');
			});
		});

		['filter-client', 'filter-status', 'filter-service'].forEach(id => {
			const el = document.getElementById(id);
			if (el) {
				el.addEventListener('change', applyFilters);
				el.addEventListener('input', applyFilters);
			}
		});

		document.getElementById('add-contract-btn')?.addEventListener('click', window.openModal);

		async function initApp() {
			const config = { apiKey: "AIzaSyA0TWb7DgZAHNl3TuoK3xQD-ANvCcQIDK4", authDomain: "fabrisgurjao.firebaseapp.com", projectId: "fabrisgurjao", storageBucket: "fabrisgurjao.firebasestorage.app", messagingSenderId: "466702265991", appId: "1:466702265991:web:78c4d98b47cab537921222", measurementId: "G-E99R5TFMQK" };
			initializeApp(config);
			db = getFirestore();
			auth = getAuth();
			contractsCollection = collection(db, 'contracts');

			onAuthStateChanged(auth, (user) => {
				const loading = document.getElementById('loading-overlay');
				const authOverlay = document.getElementById('auth-overlay');
				const appContainer = document.getElementById('app-container');
				if (user) {
					document.body.classList.toggle('is-admin', ADMIN_USERS.includes(user.displayName));
					if (!user.displayName) {
						loading.style.display = 'none';
						authOverlay.style.display = 'none';
						appContainer.style.display = 'none';
						showNameModal(user);
					} else {
						document.getElementById('user-name').textContent = user.displayName;
						loading.style.display = 'none';
						authOverlay.style.display = 'none';
						appContainer.style.display = 'block';
						onSnapshot(contractsCollection, (snap) => {
							contracts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
							updateStats();
						});
					}
				} else {
					authOverlay.style.display = 'flex';
					appContainer.style.display = 'none';
					loading.style.display = 'none';
				}
			});

			document.getElementById('login-form').addEventListener('submit', async (e) => {
				e.preventDefault();
				try {
					await signInWithEmailAndPassword(auth, document.getElementById('login-email').value, document.getElementById('login-password').value);
				} catch (err) {
					document.getElementById('auth-error').textContent = 'Email ou senha inválidos';
					document.getElementById('auth-error').classList.remove('hidden');
				}
			});

			document.getElementById('logout-button').addEventListener('click', async () => {
				await signOut(auth);
			});
		}

		function showNameModal(user) {
			const modal = document.createElement('div');
			modal.className = 'modal dark-card rounded-lg w-11/12 md:w-1/3' style="display:block";
			modal.innerHTML = \`
				<div class="p-6">
					<h2 class="text-2xl font-bold text-white mb-4">Bem-vindo!</h2>
					<p class="text-gray-400 mb-4">Qual é seu nome?</p>
					<form id="nameForm" class="space-y-4">
						<input type="text" id="nameInput" class="filter-select w-full" required>
						<button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg">Salvar</button>
					</form>
				</div>
			\`;
			document.body.appendChild(modal);
			document.getElementById('modal-backdrop').style.display = 'block';
			document.getElementById('nameForm').addEventListener('submit', async (e) => {
				e.preventDefault();
				await updateProfile(user, { displayName: document.getElementById('nameInput').value });
				modal.remove();
				location.reload();
			});
		}

		initApp();
	</script>
</body>
</html>`,
        }}
      />
    </>
  );
}
