import { TrendingUp, TrendingDown } from "lucide-react";

const colorStyles = {
  blue: {
    bg: "bg-blue-50/50",
    border: "border-blue-100",
    icon: "bg-blue-100 text-blue-600",
    accent: "text-blue-600",
  },
  red: {
    bg: "bg-red-50/50",
    border: "border-red-100",
    icon: "bg-red-100 text-red-600",
    accent: "text-red-600",
  },
  green: {
    bg: "bg-green-50/50",
    border: "border-green-100",
    icon: "bg-green-100 text-green-600",
    accent: "text-green-600",
  },
  purple: {
    bg: "bg-purple-50/50",
    border: "border-purple-100",
    icon: "bg-purple-100 text-purple-600",
    accent: "text-purple-600",
  },
};

export default function MetricCard({
  title,
  value,
  icon: Icon,
  color,
  trend,
  isNegative = false,
}) {
  const styles = colorStyles[color] || colorStyles.blue;
  const TrendIcon = isNegative ? TrendingDown : TrendingUp;
  const trendValue = trend?.replace(/[^0-9%-]/g, "");

  return (
    <div
      className={`${styles.bg} ${styles.border} border rounded-xl p-6 backdrop-blur-sm hover:shadow-lg transition duration-300`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`${styles.icon} p-3 rounded-lg`}>
          <Icon size={22} />
        </div>
        <div
          className={`flex items-center gap-1 ${isNegative ? "text-red-500" : "text-green-500"}`}
        >
          <TrendIcon size={16} />
          <span className="text-xs font-semibold">{trendValue}</span>
        </div>
      </div>

      <p className="text-xs text-slate-600 font-medium uppercase tracking-wider mb-2">
        {title}
      </p>
      <p className={`text-3xl font-bold ${styles.accent} mb-3`}>{value}</p>

      <p className="text-xs text-slate-500">{trend}</p>
    </div>
  );
}
