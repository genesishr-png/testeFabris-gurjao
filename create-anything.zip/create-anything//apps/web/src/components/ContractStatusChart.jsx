export default function ContractStatusChart() {
  return null;
}
