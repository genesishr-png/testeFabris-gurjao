import { BarChart3, Clock, AlertCircle, CheckCircle } from "lucide-react";
import MetricCard from "./MetricCard";

export default function Dashboard({ financialData }) {
  const metrics = [
    {
      title: "A Receber",
      value: `R$ ${(financialData?.aReceber || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: Clock,
      color: "blue",
      trend: "+12%",
      isNegative: false,
    },
    {
      title: "Vencido",
      value: `R$ ${(financialData?.vencido || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: AlertCircle,
      color: "red",
      trend: "-8%",
      isNegative: true,
    },
    {
      title: "Recebido",
      value: `R$ ${(financialData?.recebido || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: CheckCircle,
      color: "green",
      trend: "+5%",
      isNegative: false,
    },
    {
      title: "Contratos",
      value: (financialData?.contratos?.length || 0).toString(),
      icon: BarChart3,
      color: "purple",
      trend: "+3",
      isNegative: false,
    },
  ];

  const statusItems = [
    {
      label: "Vencidas",
      value: "12",
      bgClass: "bg-red-50",
      textClass: "text-red-600",
    },
    {
      label: "A Vencer (30d)",
      value: "28",
      bgClass: "bg-blue-50",
      textClass: "text-blue-600",
    },
    {
      label: "Pagas",
      value: "35",
      bgClass: "bg-green-50",
      textClass: "text-green-600",
    },
    {
      label: "Aguardando Êxito",
      value: "8",
      bgClass: "bg-yellow-50",
      textClass: "text-yellow-600",
    },
  ];

  const activities = [
    {
      type: "success",
      title: "Pagamento recebido",
      desc: "Contrato #2301 - R$ 15k",
      bgClass: "bg-green-50",
      borderClass: "border-green-200",
    },
    {
      type: "info",
      title: "Novo contrato",
      desc: "Contrato #2302 - João Silva",
      bgClass: "bg-blue-50",
      borderClass: "border-blue-200",
    },
    {
      type: "warning",
      title: "Parcela vencida",
      desc: "Contrato #2298 - 25/10/2025",
      bgClass: "bg-red-50",
      borderClass: "border-red-200",
    },
    {
      type: "neutral",
      title: "Contrato restaurado",
      desc: "Contrato #2295 da lixeira",
      bgClass: "bg-slate-50",
      borderClass: "border-slate-200",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Charts and Status - Left side */}
        <div className="lg:col-span-2 space-y-6">
          {/* Contract Status */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-100 hover:shadow-md transition duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-slate-800">
                Situação das Parcelas
              </h3>
              <BarChart3 size={20} className="text-slate-400" />
            </div>
            <div className="space-y-3">
              {statusItems.map((item, i) => (
                <div
                  key={i}
                  className={`${item.bgClass} p-4 rounded-lg flex items-center justify-between border border-slate-100`}
                >
                  <span className="text-slate-700 font-medium">
                    {item.label}
                  </span>
                  <span className={`text-lg font-bold ${item.textClass}`}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Performance Summary */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-5 border border-green-100">
              <p className="text-xs text-slate-600 font-semibold uppercase tracking-wide mb-2">
                Faturamento
              </p>
              <p className="text-2xl font-bold text-green-600">R$ 987.6k</p>
              <p className="text-xs text-slate-600 mt-2">
                +15% vs período anterior
              </p>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-100">
              <p className="text-xs text-slate-600 font-semibold uppercase tracking-wide mb-2">
                Taxa Recebimento
              </p>
              <p className="text-2xl font-bold text-blue-600">92%</p>
              <p className="text-xs text-slate-600 mt-2">Acima da meta 📈</p>
            </div>
          </div>
        </div>

        {/* Recent Activity - Right side */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-100 hover:shadow-md transition duration-300">
          <h3 className="text-lg font-bold text-slate-800 mb-6">
            Atividade Recente
          </h3>
          <div className="space-y-3">
            {activities.map((activity, i) => (
              <div
                key={i}
                className={`p-3 rounded-lg border-l-4 ${activity.borderClass} ${activity.bgClass}`}
              >
                <p className="text-sm font-medium text-slate-800">
                  {activity.title}
                </p>
                <p className="text-xs text-slate-600 mt-1">{activity.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Stats */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-xl p-8 shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <p className="text-slate-300 text-sm font-medium mb-2">
              Clientes Ativos
            </p>
            <p className="text-4xl font-bold">156</p>
            <p className="text-slate-400 text-xs mt-2">+12 novos este mês</p>
          </div>
          <div>
            <p className="text-slate-300 text-sm font-medium mb-2">
              Contratos em Vigência
            </p>
            <p className="text-4xl font-bold">47</p>
            <p className="text-slate-400 text-xs mt-2">
              Total de parcelas: 128
            </p>
          </div>
          <div>
            <p className="text-slate-300 text-sm font-medium mb-2">
              Receita Média
            </p>
            <p className="text-4xl font-bold">R$ 21.0k</p>
            <p className="text-slate-400 text-xs mt-2">Por contrato</p>
          </div>
        </div>
      </div>
    </div>
  );
}
