import { useState } from "react";
import {
  Menu,
  X,
  Home,
  FileText,
  BarChart3,
  Users,
  Trash2,
  LogOut,
  ChevronDown,
} from "lucide-react";
import Dashboard from "./Dashboard";
import Contracts from "./Contracts";
import Reports from "./Reports";

export default function DashboardLayout({
  auth,
  user,
  db,
  financialData,
  onLoadFinancialData,
}) {
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home, color: "text-blue-600" },
    {
      id: "contracts",
      label: "Meus Contratos",
      icon: FileText,
      color: "text-indigo-600",
    },
    {
      id: "reports",
      label: "Relatórios",
      icon: BarChart3,
      color: "text-purple-600",
    },
    {
      id: "delinquents",
      label: "Inadimplentes",
      icon: Users,
      color: "text-red-600",
    },
    { id: "trash", label: "Lixeira", icon: Trash2, color: "text-gray-600" },
  ];

  const handleLogout = async () => {
    try {
      await auth.signOut();
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard financialData={financialData} />;
      case "contracts":
        return (
          <Contracts
            db={db}
            user={user}
            onLoadFinancialData={onLoadFinancialData}
          />
        );
      case "reports":
        return <Reports financialData={financialData} />;
      default:
        return <Dashboard financialData={financialData} />;
    }
  };

  const getUserInitials = () => {
    if (!user?.displayName) return "U";
    return user.displayName
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-gradient-to-b from-slate-900 to-slate-800 text-white transition-all duration-300 fixed h-full z-50 shadow-2xl`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-slate-700 flex items-center justify-between">
          {sidebarOpen && (
            <div>
              <h2 className="font-bold text-lg text-white">FinHub</h2>
              <p className="text-xs text-slate-400">Gestão Financeira</p>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-slate-700 rounded-lg transition duration-200"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Menu Items */}
        <nav className="p-4 space-y-2 flex-1">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center ${
                  sidebarOpen ? "px-4 py-3" : "px-3 py-3 justify-center"
                } rounded-lg transition duration-200 ${
                  isActive
                    ? "bg-blue-600 shadow-lg"
                    : "hover:bg-slate-700 text-slate-300"
                }`}
              >
                <IconComponent
                  size={20}
                  className={`flex-shrink-0 ${isActive ? "text-white" : ""}`}
                />
                {sidebarOpen && (
                  <span className="ml-3 text-sm font-medium">{item.label}</span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-slate-700">
          <button
            onClick={handleLogout}
            className={`w-full flex items-center ${
              sidebarOpen ? "px-4 py-3" : "px-3 py-3 justify-center"
            } rounded-lg hover:bg-red-600/20 text-red-400 hover:text-red-300 transition duration-200`}
          >
            <LogOut size={20} />
            {sidebarOpen && (
              <span className="ml-3 text-sm font-medium">Sair</span>
            )}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div
        className={`${sidebarOpen ? "ml-64" : "ml-20"} flex-1 transition-all duration-300 flex flex-col overflow-hidden`}
      >
        {/* Top Bar */}
        <div className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between shadow-sm">
          <h1 className="text-2xl font-bold text-slate-800">
            {menuItems.find((m) => m.id === currentPage)?.label}
          </h1>

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-slate-100 transition duration-200"
            >
              <div className="text-right">
                <p className="text-sm font-semibold text-slate-800">
                  {user?.displayName || "Usuário"}
                </p>
                <p className="text-xs text-slate-500">{user?.email}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                {getUserInitials()}
              </div>
              <ChevronDown
                size={18}
                className={`text-slate-600 transition duration-200 ${
                  userMenuOpen ? "rotate-180" : ""
                }`}
              />
            </button>

            {/* Dropdown Menu */}
            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-slate-200 z-50">
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2 transition duration-200 font-medium"
                >
                  <LogOut size={16} />
                  Sair do Sistema
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto bg-slate-50">
          <div className="p-8">{renderPage()}</div>
        </div>
      </div>
    </div>
  );
}
