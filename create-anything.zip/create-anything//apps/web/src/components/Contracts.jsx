import { Edit2, Trash2, Eye, Download } from "lucide-react";
import { useState, useEffect } from "react";

export default function Contracts({ db, user, onLoadFinancialData }) {
  const [sortBy, setSortBy] = useState("date");
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Carregar contratos do Firebase quando componente montar
  useEffect(() => {
    if (db && user) {
      loadContracts();
    }
  }, [db, user]);

  const loadContracts = async () => {
    try {
      const { collection, query, where, getDocs } = await import(
        "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js"
      );

      const contractsRef = collection(db, "contratos");
      const q = query(contractsRef, where("userId", "==", user.uid));
      const querySnapshot = await getDocs(q);

      const contractsData = [];
      querySnapshot.forEach((doc) => {
        contractsData.push({ id: doc.id, ...doc.data() });
      });

      setContracts(contractsData);
      setLoading(false);

      // Recarregar dados financeiros após carregar contratos
      if (onLoadFinancialData) {
        onLoadFinancialData(db, user.uid);
      }
    } catch (error) {
      console.error("Erro ao carregar contratos:", error);
      setLoading(false);
    }
  };

  const statusColors = {
    green: "bg-green-100 text-green-700",
    red: "bg-red-100 text-red-700",
    blue: "bg-blue-100 text-blue-700",
  };

  return (
    <div className="space-y-6">
      {/* Header with Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex-1">
          <h2 className="text-xl font-bold text-gray-800 mb-2">Contratos</h2>
          <p className="text-sm text-gray-600">
            Total de {contracts.length} contratos ativos
          </p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm font-medium text-gray-700">
            <Download size={18} />
            <span>Exportar (CSV)</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition text-sm font-medium">
            <span>+ Novo Contrato</span>
          </button>
        </div>
      </div>

      {/* Sort Options */}
      <div className="flex items-center gap-4">
        <label className="text-sm font-medium text-gray-700">
          Ordenar por:
        </label>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
        >
          <option value="date">Data de Vencimento</option>
          <option value="value">Valor do Contrato</option>
          <option value="client">Nome do Cliente</option>
          <option value="status">Status</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  ID
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  Cliente
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  Valor
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  Vencimento
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  Status
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">
                  Progresso
                </th>
                <th className="px-6 py-4 text-center text-xs font-semibold text-gray-700 uppercase">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody>
              {contracts.map((contract, index) => (
                <tr
                  key={contract.id}
                  className={`border-b border-gray-100 hover:bg-gray-50 transition ${
                    index % 2 === 0 ? "bg-white" : "bg-gray-50"
                  }`}
                >
                  <td className="px-6 py-4">
                    <span className="font-bold text-gray-800">
                      {contract.id}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-gray-700">{contract.client}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-semibold text-gray-800">
                      {contract.value}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-gray-700">{contract.dueDate}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[contract.statusColor]}`}
                    >
                      {contract.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          contract.progress === 0
                            ? "bg-red-500"
                            : contract.progress < 50
                              ? "bg-yellow-500"
                              : "bg-green-500"
                        }`}
                        style={{ width: `${contract.progress}%` }}
                      ></div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center gap-2">
                      <button className="p-2 hover:bg-blue-100 text-blue-600 rounded-lg transition">
                        <Eye size={18} />
                      </button>
                      <button className="p-2 hover:bg-gray-200 text-gray-600 rounded-lg transition">
                        <Edit2 size={18} />
                      </button>
                      <button className="p-2 hover:bg-red-100 text-red-600 rounded-lg transition">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600">Mostrando 1 a 5 de 47 contratos</p>
        <div className="flex gap-2">
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm text-gray-700">
            ← Anterior
          </button>
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm text-gray-700">
            Próximo →
          </button>
        </div>
      </div>
    </div>
  );
}
