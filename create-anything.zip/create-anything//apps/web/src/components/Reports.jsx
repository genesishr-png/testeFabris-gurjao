import { Download, Filter, Calendar } from "lucide-react";
import { useState } from "react";

export default function Reports() {
  const [dateRange, setDateRange] = useState("month");

  const reports = [
    {
      title: "Relatório de Recebimentos",
      description: "Análise completa de todos os pagamentos recebidos",
      lastUpdated: "30/10/2025",
      data: "R$ 89.200,00",
    },
    {
      title: "Relatório de Inadimplência",
      description: "Contratos com parcelas vencidas não pagas",
      lastUpdated: "30/10/2025",
      data: "12 contratos",
    },
    {
      title: "Relatório de Faturamento",
      description: "Receita total e projeção mensal",
      lastUpdated: "30/10/2025",
      data: "R$ 987.650,00",
    },
    {
      title: "Relatório de Clientes",
      description: "Lista e análise de desempenho por cliente",
      lastUpdated: "29/10/2025",
      data: "156 clientes",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">
            Relatórios Financeiros
          </h2>
          <p className="text-sm text-gray-600">
            Gere e exporte relatórios em diversos formatos
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100 flex flex-col md:flex-row md:items-center gap-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Período
          </label>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg text-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            <option value="week">Última Semana</option>
            <option value="month">Último Mês</option>
            <option value="quarter">Último Trimestre</option>
            <option value="year">Último Ano</option>
            <option value="custom">Personalizado</option>
          </select>
        </div>
        <div className="flex gap-3 md:pt-6">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 bg-white text-gray-700 rounded-lg hover:bg-gray-50 transition font-medium">
            <Filter size={18} />
            Filtrar
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition font-medium">
            <Calendar size={18} />
            Gerar
          </button>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {reports.map((report, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-md border border-gray-100 p-6 hover:shadow-lg transition"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {report.title}
                </h3>
                <p className="text-sm text-gray-600">{report.description}</p>
              </div>
              <button className="p-2 hover:bg-blue-100 text-blue-600 rounded-lg transition">
                <Download size={20} />
              </button>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500 mb-1">
                    Última atualização
                  </p>
                  <p className="text-sm font-medium text-gray-700">
                    {report.lastUpdated}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500 mb-1">Valor/Quantidade</p>
                  <p className="text-lg font-bold text-blue-600">
                    {report.data}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Advanced Analytics */}
      <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl shadow-md border border-indigo-200 p-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4">
          Análise Avançada
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-sm text-gray-600 font-medium mb-2">
              Crescimento Mensal
            </p>
            <p className="text-3xl font-bold text-indigo-600">+15%</p>
            <p className="text-xs text-gray-600 mt-1">vs. período anterior</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 font-medium mb-2">
              Ticket Médio
            </p>
            <p className="text-3xl font-bold text-blue-600">R$ 21.000</p>
            <p className="text-xs text-gray-600 mt-1">valor por contrato</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 font-medium mb-2">
              Tempo Médio
            </p>
            <p className="text-3xl font-bold text-purple-600">45 dias</p>
            <p className="text-xs text-gray-600 mt-1">até recebimento</p>
          </div>
        </div>
      </div>

      {/* Report Schedule */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">
          Relatórios Agendados
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Relatório Mensal</p>
              <p className="text-sm text-gray-600">
                Enviado automaticamente todo dia 1º do mês
              </p>
            </div>
            <button className="px-3 py-1 text-sm font-medium text-gray-600 hover:text-red-600 transition">
              Cancelar
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Relatório Semanal</p>
              <p className="text-sm text-gray-600">
                Enviado toda segunda-feira às 08:00
              </p>
            </div>
            <button className="px-3 py-1 text-sm font-medium text-gray-600 hover:text-red-600 transition">
              Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
